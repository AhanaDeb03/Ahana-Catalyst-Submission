# 🎬 TalentAI Scout — Demo Video Script
**Target duration: 3–5 minutes**

---

## 🎙️ OPENING (0:00 – 0:25)

**[Screen: blank / title card]**

> "Recruiters today spend hours manually sifting through LinkedIn profiles, guessing who might be interested, and firing off cold emails into the void. What if an AI could do all of that — and score not just *how well* someone matches a role, but *how genuinely interested* they are?"

> "This is TalentAI Scout — my submission for the Catalyst Hackathon. Let me show you how it works."

---

## 🗺️ ARCHITECTURE OVERVIEW (0:25 – 0:55)

**[Screen: architecture.svg]**

> "The system has four layers. At the top, we feed in a Job Description. The AI parses it — extracting required skills, seniority, domain, and nice-to-haves."

> "Then for each candidate in the pool, Claude scores them on a Match Score from 0 to 100 — with full explainability: why they matched, and what's missing."

> "The magic happens in layer three: the Conversational Outreach Agent. Claude holds a real multi-turn conversation with each candidate, assessing genuine interest and outputting an Interest Score."

> "Finally, both scores combine into a ranked shortlist the recruiter can act on immediately."

---

## 🚀 LIVE DEMO (0:55 – 3:30)

### Part 1 — JD Input (0:55 – 1:20)

**[Screen: App open on JD Input tab]**

> "I've pre-loaded a realistic Job Description for a Senior Full-Stack Engineer at a FinTech startup — looking for React, TypeScript, Node.js, AWS, with payments domain experience."

> "This is exactly the kind of role where finding the right person is hard. Let me hit Scout Candidates."

**[Click Scout Candidates]**

---

### Part 2 — Live Scouting (1:20 – 1:55)

**[Screen: Scouting animation, each candidate populating with a score]**

> "Watch what happens — Claude is analyzing each candidate in real-time against the JD."

> "Priya Sharma — 91. Sneha Rao — 87. Arjun Mehta — 74."

> "Each score comes with match reasons and gaps — this isn't a black box. The recruiter knows exactly *why* each person ranked where they did."

**[Shortlist appears]**

---

### Part 3 — Shortlist View (1:55 – 2:25)

**[Screen: Shortlist grid with Match Scores]**

> "Here's the shortlist, ranked by Match Score. You can see the explainability panel on each card — matched skills highlighted in green, gaps in red."

> "But Match Score alone isn't enough. Someone can look perfect on paper and have zero interest in moving. That's where the Interest Score comes in."

> "Let me click on Priya Sharma to start the AI outreach."

---

### Part 4 — Conversational Outreach (2:25 – 3:10)

**[Screen: Chat panel opens]**

> "The AI agent opens the conversation naturally — introducing the opportunity, not a cold pitch."

**[Type a response as Priya: "Thanks for reaching out! I'm actually pretty happy at Razorpay, but I'm open to hearing more. What's the role?"]**

> "I'm playing Priya here. She's cautiously open. Let's see how the agent responds..."

**[AI replies, continue 2 more exchanges]**

**[Type: "The tech stack sounds interesting. The startup stage is a bit of a concern though. What's the team size?"]**

**[Type: "Okay that's helpful. I'd probably need at least 6 weeks notice."]**

> "After four exchanges, the agent has enough signal. Watch the Interest Score populate — 72 out of 100. High interest level, motivated by technical challenge, available in 6 weeks."

---

### Part 5 — Combined Ranking (3:10 – 3:35)

**[Screen: Scroll to combined ranking table]**

> "Now both scores are live. The combined ranking is Match plus Interest, divided by two."

> "Priya sits at rank 1 with an 84 combined score. Sneha, despite a high Match Score, hasn't been engaged yet — so her Interest Score is pending."

> "This gives recruiters a genuinely actionable shortlist — not just who looks good, but who's actually ready to move."

---

## 🏁 CLOSING (3:35 – 4:00)

**[Screen: App overview / architecture]**

> "TalentAI Scout solves a real recruiter pain: the gap between profile matching and genuine candidate engagement."

> "The dual-score system — Match and Interest — gives hiring teams something no ATS does today: a ranked shortlist that's both skills-verified and interest-confirmed."

> "Built with React, powered by Claude. All source code is on GitHub, link in the description."

> "Thanks for watching."

---

## 📋 RECORDING TIPS

- **Resolution:** 1920×1080 minimum
- **Cursor:** Use a cursor highlighter (e.g. Cursor Highlighter, ScreenBrush)
- **Pace:** Don't rush the scoring animation — let viewers see the scores populate
- **Tool:** Loom, OBS, or QuickTime work great for this
- **Background music:** Optional, keep it subtle (lo-fi works well)
- **Captions:** Add auto-captions in YouTube or Loom for accessibility

---

## ⏱️ TIMING SUMMARY

| Section | Time | Duration |
|---|---|---|
| Opening hook | 0:00 | 25s |
| Architecture overview | 0:25 | 30s |
| JD Input demo | 0:55 | 25s |
| Live scouting animation | 1:20 | 35s |
| Shortlist walkthrough | 1:55 | 30s |
| Outreach conversation | 2:25 | 45s |
| Combined ranking reveal | 3:10 | 25s |
| Closing | 3:35 | 25s |
| **Total** | | **~4:00** |
