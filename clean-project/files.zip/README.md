# 🎯 TalentAI Scout

> **AI-Powered Talent Scouting & Engagement Agent** — Catalyst Hackathon Submission

TalentAI Scout is a fully AI-driven recruiting agent that takes a Job Description as input, discovers and ranks matching candidates, conducts simulated conversational outreach to assess genuine interest, and outputs a dual-scored shortlist — ready for the recruiter to act on immediately.

---

## 🚀 Live Demo

**Deployed URL:** `https://your-deployment-url.vercel.app`

**Demo Video:** `https://your-video-link-here`

---

## ✨ Features

| Feature | Description |
|---|---|
| **JD Parsing** | Claude AI extracts required skills, seniority, domain, and nice-to-haves from raw JD text |
| **Candidate Discovery** | Matches candidates from pool against parsed JD requirements |
| **Match Scoring (0–100)** | Per-candidate score with `matchReasons[]` and `gaps[]` for explainability |
| **Conversational Outreach** | Multi-turn AI chat simulating candidate engagement |
| **Interest Scoring (0–100)** | Extracted from conversation — motivations, timeline, openness |
| **Combined Ranking** | `(matchScore + interestScore) / 2` — recruiter-ready shortlist |
| **Explainability Panel** | Every score explained: why they matched, what's missing, what motivates them |

---

## 🏗️ Architecture

```
┌─────────────────────┐   ┌──────────────────────┐   ┌─────────────────────┐
│   Job Description   │   │   Candidate Pool     │   │  Recruiter Config   │
│  (raw text input)   │   │ (profiles + skills)  │   │ (weights/filters)   │
└────────┬────────────┘   └──────────┬───────────┘   └──────────┬──────────┘
         │                           │                           │
         ▼                           ▼                           ▼
┌─────────────────────┐   ┌──────────────────────┐   ┌─────────────────────┐
│     JD Parser       │   │  Candidate Matcher   │   │   Scoring Engine    │
│ Skills · Level ·    │   │ Skill overlap ·      │   │ Weighted formula ·  │
│ Domain · Must-haves │   │ Domain fit · Gaps    │   │ Match Score 0-100   │
└────────┬────────────┘   └──────────┬───────────┘   └──────────┬──────────┘
         └───────────────────────────┼───────────────────────────┘
                                     ▼
                     ┌───────────────────────────────┐
                     │     Claude AI Engine          │
                     │   claude-sonnet-4-20250514    │
                     │  JD Analysis · Match Scoring  │
                     │  Conversational Outreach      │
                     └──────────────┬────────────────┘
                                    │
                   ┌────────────────┼────────────────┐
                   ▼                ▼                 ▼
           ┌──────────────┐ ┌─────────────┐ ┌──────────────────┐
           │ Ranked       │ │Explainability│ │ Recruiter Action │
           │ Shortlist    │ │ Panel        │ │ (chat/export)    │
           │Match+Interest│ │Reasons·Gaps │ │                  │
           └──────────────┘ └─────────────┘ └──────────────────┘
```

### Scoring Logic

**Match Score (0–100)**
```
Inputs:  Candidate skills, experience, domain, company background
Process: Claude evaluates overlap with JD requirements
Output:  { matchScore: 85, matchReasons: [...], gaps: [...] }
```

**Interest Score (0–100)**
```
Inputs:  Multi-turn conversation with candidate (simulated)
Process: Claude tracks sentiment, probes motivations, assesses openness
Output:  { interestScore: 72, motivations: [...], timeline: "1-2 months" }
Trigger: Emitted as structured INTEREST_DATA:{} block after 4+ exchanges
```

**Combined Score**
```
combinedScore = (matchScore + interestScore) / 2
```

---

## 🛠️ Tech Stack

- **Frontend:** React 18 + Vite
- **AI:** Anthropic Claude API (`claude-sonnet-4-20250514`)
- **Styling:** Pure CSS-in-JS (no external UI library)
- **Deployment:** Vercel / Netlify

---

## 📦 Local Setup

### Prerequisites
- Node.js 18+
- Anthropic API key

### 1. Clone the repo
```bash
git clone https://github.com/your-username/talentai-scout
cd talentai-scout
```

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment
```bash
cp .env.example .env
# Add your Anthropic API key to .env:
# VITE_ANTHROPIC_API_KEY=sk-ant-...
```

> ⚠️ **For hackathon demo:** The API key is handled by the Claude.ai artifact proxy. For production, implement a backend proxy — never expose API keys in client code.

### 4. Run locally
```bash
npm run dev
# Open http://localhost:5173
```

### 5. Build for production
```bash
npm run build
npm run preview
```

---

## 📂 Project Structure

```
talentai-scout/
├── src/
│   ├── App.jsx              # Main application (single-file React)
│   ├── main.jsx             # Entry point
│   └── index.css            # Base styles
├── public/
│   └── architecture.svg     # System architecture diagram
├── .env.example
├── package.json
├── vite.config.js
└── README.md
```

---

## 🔄 User Flow

```
1. PASTE JD  →  2. SCOUT  →  3. VIEW SHORTLIST  →  4. ENGAGE CANDIDATE  →  5. RANKED OUTPUT
   (raw text)     (AI scores    (ranked by Match      (AI chat, assess       (Match + Interest
                  all candidates)   Score)               genuine interest)       combined score)
```

---

## 📊 Sample Input / Output

### Input: Job Description
```
Senior Full-Stack Engineer – FinTech
Experience: 4–8 years
Required: React, TypeScript, Node.js, PostgreSQL, AWS
Domain: Payments / embedded finance
```

### Output: Candidate Shortlist
```json
[
  {
    "rank": 1,
    "name": "Priya Sharma",
    "matchScore": 91,
    "interestScore": 78,
    "combinedScore": 84,
    "matchReasons": [
      "6 years FinTech experience at Razorpay",
      "Full React + TypeScript + Node.js stack",
      "AWS infrastructure experience"
    ],
    "gaps": ["No Kafka/event-driven experience mentioned"],
    "interestAnalysis": {
      "level": "High",
      "motivations": ["Technical challenge", "Growth trajectory"],
      "timeline": "Available in 4–6 weeks"
    }
  },
  ...
]
```

---

## 🎥 Demo Video Script

See `DEMO_SCRIPT.md` for the full 3–5 minute walkthrough script.

---

## 👤 Author

**[Your Name]**  
GitHub: [@your-username](https://github.com/your-username)  
Hackathon: Catalyst by Deccan AI

---

## 📄 License

MIT
